﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using QLBH.DB;

namespace QLBH.ConnectDB
{
    public class SP
    {
        QUANLYBANHANGEntities db = new QUANLYBANHANGEntities();

        public tb_SanPham getItem(int id)
        {
            return db.tb_SanPham.FirstOrDefault(x => x.MaSP == id);
        }

        public List<tb_SanPham> getList()
        {
            return db.tb_SanPham.ToList();
        }


        //public List<object> getList()
        //{
        //    var query = db.tb_SanPham
        //        .Join(db.tb_DanhMucSP,
        //              sp => sp.MaSP,
        //              dm => dm.MaDM,
        //              (sp, dm) => new { sp, dm }) 
        //        .Select(temp => new
        //        {
        //            temp.sp.MaSP,
        //            temp.sp.TenSP,
        //            temp.sp.GiaBan,
        //            temp.sp.GiaNhap,
        //            temp.sp.SoLuongTonKho,
        //            temp.sp.HSD,
        //            temp.sp.Hinhanh,
        //            TenDM = temp.dm.TenDM 
        //        })
        //        .ToList<object>();

        //    return query;
        //}









        public tb_SanPham Add(tb_SanPham sp)
        {
            try
            {
                db.tb_SanPham.Add(sp);
                db.SaveChanges();
                return sp;
            }
            catch (Exception ex)
            {
                throw new Exception("Loi: " + ex.Message);
            }
        }
        public tb_SanPham Update(tb_SanPham sp)
        {
            try
            {
                var _sp = db.tb_SanPham.FirstOrDefault(x => x.MaSP == sp.MaSP);
                _sp.TenSP = sp.TenSP;
                _sp.GiaBan = sp.GiaBan;
                _sp.GiaNhap = sp.GiaNhap;
                _sp.HSD = sp.HSD;
                _sp.SoLuongTonKho = sp.SoLuongTonKho;
                _sp.MaDM = sp.MaDM;
                db.SaveChanges();
                return sp;
            }
            catch (Exception ex)
            {
                throw new Exception("Loi: " + ex.Message);
            }
        }

        public void Detele(int id)
        {
            try
            {
                var _sp = db.tb_SanPham.FirstOrDefault(x => x.MaSP == id);
                db.tb_SanPham.Remove(_sp);
                db.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception("Loi: " + ex.Message);
            }
        }
    }
}
