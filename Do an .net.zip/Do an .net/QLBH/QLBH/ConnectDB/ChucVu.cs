﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using QLBH.DB;

namespace QLBH.ConnectDB
{
    public class ChucVu
    {
        QUANLYBANHANGEntities db = new QUANLYBANHANGEntities();

        public tb_ChucVu getItem(int id)
        {
            return db.tb_ChucVu.FirstOrDefault(x=>x.IDCV==id);
        }
        //public List<tb_ChucVu> getList()
        //{
        //    return db.tb_ChucVu.ToList();
        //}
        public List<object> getList()
        {
            var query = db.tb_ChucVu
                .Select(x => new
                {
                    x.IDCV,
                    x.TenCV
                })
                .ToList<object>();  // Chuyển về danh sách object để tương thích với DataGridView

            return query;
        }

        public tb_ChucVu Add(tb_ChucVu cv)
        {
            try
            {
                db.tb_ChucVu.Add(cv);
                db.SaveChanges();
                return cv;
            }
            catch (Exception ex)
            {
                throw new Exception("Loi: " + ex.Message);
            }
        }
        public tb_ChucVu Update(tb_ChucVu cv)
        {
            try
            {
                var _cv = db.tb_ChucVu.FirstOrDefault(x => x.IDCV == cv.IDCV);
                _cv.TenCV = cv.TenCV;
                db.SaveChanges();
                return cv;
            }
            catch (Exception ex)
            {
                throw new Exception("Loi: " + ex.Message);
            }
        }

        public void Detele(int id)
        {
            try
            {
                var _cv = db.tb_ChucVu.FirstOrDefault(x => x.IDCV == id);
                db.tb_ChucVu.Remove(_cv);
                db.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception("Loi: " + ex.Message);
            }
        }
    }
}
