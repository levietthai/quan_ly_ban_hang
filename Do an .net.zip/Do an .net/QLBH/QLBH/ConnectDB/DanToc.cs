﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using QLBH.DB;

namespace QLBH.ConnectDB
{
    public class DanToc
    {
        QUANLYBANHANGEntities db = new QUANLYBANHANGEntities();

        public tb_DanToc getItem(int id)
        {
            return db.tb_DanToc.FirstOrDefault(x => x.IDDT == id);
        }
        //public List<tb_DanToc> getList()
        //{
        //    return db.tb_DanToc.ToList();
        //}
        public List<object> getList()
        {
            var query = db.tb_DanToc
                .Select(x => new
                {
                    x.IDDT,
                    x.TenDT
                })
                .ToList<object>();  // Chuyển về danh sách object để tương thích với DataGridView

            return query;
        }

        public tb_DanToc Add(tb_DanToc dt)
        {
            try
            {
                db.tb_DanToc.Add(dt);
                db.SaveChanges();
                return dt;
            }
            catch (Exception ex)
            {
                throw new Exception("Loi: " + ex.Message);
            }
        }
        public tb_DanToc Update(tb_DanToc dt)
        {
            try
            {
                var _dt = db.tb_DanToc.FirstOrDefault(x => x.IDDT == dt.IDDT);
                _dt.TenDT = dt.TenDT;
                db.SaveChanges();
                return dt;
            }
            catch (Exception ex)
            {
                throw new Exception("Loi: " + ex.Message);
            }
        }

        public void Detele(int id)
        {
            try
            {
                var _dt = db.tb_DanToc.FirstOrDefault(x => x.IDDT == id);
                db.tb_DanToc.Remove(_dt);
                db.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception("Loi: " + ex.Message);
            }
        }
    }
}
