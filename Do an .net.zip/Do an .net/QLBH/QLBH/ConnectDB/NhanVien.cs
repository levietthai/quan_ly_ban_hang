﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using QLBH.DB;
using System.Configuration;

namespace QLBH.ConnectDB
{
    public class NhanVien
    {
        QUANLYBANHANGEntities db = new QUANLYBANHANGEntities();
        public tb_NhanVien getItem(int id)
        {
            return db.tb_NhanVien.FirstOrDefault(x => x.MaNV == id);
        }
        //public List<tb_NhanVien> getList()
        //{
        //    return db.tb_NhanVien.ToList();
        //}
        public List<object> getList()
        {
            var query = db.tb_NhanVien
                .Join(db.tb_ChucVu,
                      nv => nv.IDCV,
                      cv => cv.IDCV,
                      (nv, cv) => new { nv, cv }) // Giữ cả nhân viên và chức vụ
                .Join(db.tb_TrinhDo,
                      temp => temp.nv.IDTD,
                      td => td.IDTD,
                      (temp, td) => new { temp.nv, temp.cv, td }) // Giữ nhân viên, chức vụ và trình độ
                .Join(db.tb_TonGiao,
                      temp => temp.nv.IDTG,
                      tg => tg.IDTG,
                      (temp, tg) => new { temp.nv, temp.cv, temp.td, tg }) // Giữ thêm tôn giáo
                .Join(db.tb_DanToc,
                      temp => temp.nv.IDDT,
                      dt => dt.IDDT,
                      (temp, dt) => new
                      {
                          temp.nv.MaNV,
                          temp.nv.HoTen,
                          temp.nv.GioiTinh,
                          temp.nv.NgaySinh,
                          temp.nv.DienThoai,
                          temp.nv.CCCD,
                          temp.nv.DiaChi,
                          temp.nv.HinhAnh,
                          temp.nv.TenDN,
                          temp.nv.MatKhau,
                          TenChucVu = temp.cv.TenCV,  // Lấy tên chức vụ từ bảng tb_ChucVu
                          TenTrinhDo = temp.td.TenTD, // Lấy tên trình độ từ bảng tb_TrinhDo
                          TenTonGiao = temp.tg.TenTG, // Lấy tên tôn giáo từ bảng tb_TonGiao
                          TenDanToc = dt.TenDT        // Lấy tên dân tộc từ bảng tb_DanToc
                      })
                .ToList<object>(); // Chuyển về danh sách object để tương thích với DataGridView

            return query;
        }

        //public DataTable getNhanVien()
        //{
        //    string query = @"
        //SELECT tb_NhanVien.MaNV, tb_NhanVien.HoTen, tb_NhanVien.GioiTinh, 
        //       tb_NhanVien.CCCD, tb_NhanVien.DienThoai, tb_NhanVien.HinhAnh,
        //       tb_NhanVien.NgaySinh, tb_NhanVien.TenDN, tb_NhanVien.MatKhau, 
        //       tb_ChucVu.TenCV
        //FROM tb_NhanVien
        //FULL JOIN tb_ChucVu ON tb_NhanVien.IDCV = tb_ChucVu.IDCV";

        //    // Lấy chuỗi kết nối từ cấu hình trong App.config
        //    string connStr = ConfigurationManager.ConnectionStrings["QUANLYBANHANGEntities"].ConnectionString;

        //    using (SqlConnection conn = new SqlConnection(connStr))
        //    {
        //        conn.Open();
        //        SqlDataAdapter da = new SqlDataAdapter(query, conn);
        //        DataTable dt = new DataTable();
        //        da.Fill(dt);
        //        return dt;
        //    }
        //}


        public tb_NhanVien Add(tb_NhanVien nv)
        {
            try
            {
                db.tb_NhanVien.Add(nv);
                db.SaveChanges();
                return nv;
            }
            catch (Exception ex)
            {
                throw new Exception("Loi: " + ex.Message);
            }
        }
        public tb_NhanVien Update(tb_NhanVien nv)
        {
            try
            {
                var _nv = db.tb_NhanVien.FirstOrDefault(x => x.MaNV == nv.MaNV);
                _nv.HoTen = nv.HoTen;
                _nv.GioiTinh = nv.GioiTinh;
                _nv.CCCD = nv.CCCD;
                _nv.DiaChi = nv.DiaChi;
                _nv.HinhAnh = nv.HinhAnh;
                _nv.DienThoai = nv.DienThoai;
                _nv.IDCV = nv.IDCV;
                _nv.IDTD = nv.IDTD;
                _nv.NgaySinh = nv.NgaySinh;
                _nv.TenDN = nv.TenDN;
                _nv.MatKhau = nv.MatKhau;
                _nv.IDDT = nv.IDDT;
                _nv.IDTG = nv.IDTG;
                db.SaveChanges();
                return nv;
            }
            catch (Exception ex)
            {
                throw new Exception("Loi: " + ex.Message);
            }
        }

        public void Detele(int id)
        {
            try
            {
                var _nv = db.tb_NhanVien.FirstOrDefault(x => x.MaNV == id);
                db.tb_NhanVien.Remove(_nv);
                db.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception("Loi: " + ex.Message);
            }
        }
    }
}
