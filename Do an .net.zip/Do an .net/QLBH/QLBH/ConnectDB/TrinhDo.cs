﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using QLBH.DB;

namespace QLBH.ConnectDB
{
    public class TrinhDo
    {
        QUANLYBANHANGEntities db = new QUANLYBANHANGEntities();
        public tb_TrinhDo getItem(int id)
        {
            return db.tb_TrinhDo.FirstOrDefault(x=>x.IDTD==id);
        }
        //public List<tb_TrinhDo> getList()
        //{
        //    return db.tb_TrinhDo.ToList();
        //}
        public List<object> getList()
        {
            var query = db.tb_TrinhDo
                .Select(x => new
                {
                    x.IDTD,
                    x.TenTD
                })
                .ToList<object>();  // Chuyển về danh sách object để tương thích với DataGridView

            return query;
        }

        public tb_TrinhDo Add(tb_TrinhDo td)
        {
            try
            {
                db.tb_TrinhDo.Add(td);
                db.SaveChanges();
                return td;
            }
            catch(Exception ex) 
            {
                throw new Exception("Loi: " + ex.Message);
            }
        }
        public tb_TrinhDo Update(tb_TrinhDo td)
        {
            try
            {
                var _td = db.tb_TrinhDo.FirstOrDefault(x=>x.IDTD==td.IDTD);
                _td.TenTD = td.TenTD;
                db.SaveChanges();
                return td;
            }
            catch (Exception ex)
            {
                throw new Exception("Loi: " + ex.Message);
            }
        }

        public void Detele(int id)
        {
            try
            {
                var _td = db.tb_TrinhDo.FirstOrDefault(x => x.IDTD == id);
                db.tb_TrinhDo.Remove(_td);
                db.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception("Loi: " + ex.Message);
            }
        }
    }
}
