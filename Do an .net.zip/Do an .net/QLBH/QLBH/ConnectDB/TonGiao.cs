﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using QLBH.DB;

namespace QLBH.ConnectDB
{
    public class TonGiao
    {
        QUANLYBANHANGEntities db = new QUANLYBANHANGEntities();

        public tb_TonGiao getItem(int id)
        {
            return db.tb_TonGiao.FirstOrDefault(x => x.IDTG == id);
        }
        //public List<tb_TonGiao> getList()
        //{
        //    return db.tb_TonGiao.ToList();
        //}
        public List<object> getList()
        {
            var query = db.tb_TonGiao
                .Select(x => new
                {
                    x.IDTG,
                    x.TenTG
                })
                .ToList<object>();  // Chuyển về danh sách object để tương thích với DataGridView

            return query;
        }

        public tb_TonGiao Add(tb_TonGiao tg)
        {
            try
            {
                db.tb_TonGiao.Add(tg);
                db.SaveChanges();
                return tg;
            }
            catch (Exception ex)
            {
                throw new Exception("Loi: " + ex.Message);
            }
        }
        public tb_TonGiao Update(tb_TonGiao tg)
        {
            try
            {
                var _tg = db.tb_TonGiao.FirstOrDefault(x => x.IDTG == tg.IDTG);
                _tg.TenTG = tg.TenTG;
                db.SaveChanges();
                return tg;
            }
            catch (Exception ex)
            {
                throw new Exception("Loi: " + ex.Message);
            }
        }

        public void Detele(int id)
        {
            try
            {
                var _tg = db.tb_TonGiao.FirstOrDefault(x => x.IDTG == id);
                db.tb_TonGiao.Remove(_tg);
                db.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception("Loi: " + ex.Message);
            }
        }
    }
}
