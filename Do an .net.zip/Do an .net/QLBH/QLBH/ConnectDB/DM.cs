﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using QLBH.DB;

namespace QLBH.ConnectDB
{
    public class DM
    {
        QUANLYBANHANGEntities db = new QUANLYBANHANGEntities();

        public tb_DanhMucSP getItem(int id)
        {
            return db.tb_DanhMucSP.FirstOrDefault(x => x.MaDM == id);
        }

        public List<tb_DanhMucSP> getList()
        {
            return db.tb_DanhMucSP.ToList();
        }

        public tb_DanhMucSP Add(tb_DanhMucSP dt)
        {
            try
            {
                db.tb_DanhMucSP.Add(dt);
                db.SaveChanges();
                return dt;
            }
            catch (Exception ex)
            {
                throw new Exception("Loi: " + ex.Message);
            }
        }
        public tb_DanhMucSP Update(tb_DanhMucSP dt)
        {
            try
            {
                var _dt = db.tb_DanhMucSP.FirstOrDefault(x => x.MaDM == dt.MaDM);
                _dt.MaDM = dt.MaDM;
                db.SaveChanges();
                return dt;
            }
            catch (Exception ex)
            {
                throw new Exception("Loi: " + ex.Message);
            }
        }

        public void Detele(int id)
        {
            try
            {
                var _dt = db.tb_DanhMucSP.FirstOrDefault(x => x.MaDM == id);
                db.tb_DanhMucSP.Remove(_dt);
                db.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception("Loi: " + ex.Message);
            }
        }
    }
}
