﻿using QLBH.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLBH.ConnectDB
{
    public class DangKyclass
    {
        QUANLYBANHANGEntities db = new QUANLYBANHANGEntities();

        public tb_Users Add(tb_Users us)
        {
            try
            {
                db.tb_Users.Add(us);
                db.SaveChanges();
                return us;
            }
            catch (Exception ex)
            {
                throw new Exception("Loi: " + ex.Message);
            }
        }
    }
}
