﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using QLBH.ConnectDB;
using QLBH.DB;

namespace QLBH.frmQL.btnNV
{
    public partial class ucDT : UserControl
    {
        public ucDT()
        {
            InitializeComponent();
        }

        DanToc _dantoc;
        bool _them;
        int _id;

        private void ucDT_Load(object sender, EventArgs e)
        {
            _them = false;
            _dantoc = new DanToc();
            _showHide(true);
            loadData();
        }

        void _showHide(bool kt)
        {
            tsbLuu.Enabled = !kt;
            tsbHuy.Enabled = !kt;
            tsbThem.Enabled = kt;
            tsbSua.Enabled = kt;
            tsbXoa.Enabled = kt;
            txtTen.Enabled = !kt;
        }

        void loadData()
        {
            dgvDSDT.DataSource = _dantoc.getList();
            // dgvDSTD.OptionsBehavior = false;// khong duong 
            // Chặn chỉnh sửa dữ liệu
            dgvDSDT.ReadOnly = true;

            // Ngăn người dùng thêm hoặc xóa dòng
            dgvDSDT.AllowUserToAddRows = false;
            dgvDSDT.AllowUserToDeleteRows = false;

            // Ngăn người dùng sắp xếp cột
            foreach (DataGridViewColumn column in dgvDSDT.Columns)
            {
                column.SortMode = DataGridViewColumnSortMode.NotSortable;
            }

            // Tắt chế độ chọn nhiều ô/cột/hàng cùng lúc
            dgvDSDT.MultiSelect = false;

            // Chặn di chuyển cột
            dgvDSDT.AllowUserToOrderColumns = false;

            // Tắt chọn cả dòng khi click vào ô
            dgvDSDT.SelectionMode = DataGridViewSelectionMode.CellSelect;
        }

        private void tsbThem_Click(object sender, EventArgs e)
        {
            _showHide(false);
            _them = true;
            txtTen.Text = string.Empty;
        }

        private void tsbSua_Click(object sender, EventArgs e)
        {
            _them = false;
            _showHide(false);
        }

        private void tsbXoa_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Ban co chac chan xoa khong?", "Thong bao", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                _dantoc.Detele(_id);
                loadData();
            }
        }

        private void tsbLuu_Click(object sender, EventArgs e)
        {
            SaveData();
            loadData();
            _them = false;
            _showHide(true);
        }

        private void tsbHuy_Click(object sender, EventArgs e)
        {
            _them = false;
            _showHide(true);
        }

        void SaveData()
        {
            if (_them)
            {
                tb_DanToc dt = new tb_DanToc();
                dt.TenDT = txtTen.Text;
                _dantoc.Add(dt);
            }
            else
            {
                var dt = _dantoc.getItem(_id);
                dt.TenDT = txtTen.Text;
                _dantoc.Update(dt);
            }
        }

        private void dgvDSDT_Click(object sender, EventArgs e)
        {
            _id = Convert.ToInt32(dgvDSDT.CurrentRow.Cells["IDDT"].Value);
            txtTen.Text = dgvDSDT.CurrentRow.Cells["TenDT"].Value.ToString();
        }
    }
}
