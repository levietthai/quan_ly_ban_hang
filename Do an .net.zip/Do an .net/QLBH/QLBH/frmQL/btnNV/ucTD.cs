﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.Pkcs;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using QLBH.ConnectDB;
using QLBH.DB;

namespace QLBH.frmQL.btnNV
{
    public partial class ucTD : UserControl
    {
        public ucTD()
        {
            InitializeComponent();
        }

        TrinhDo _trinhdo;
        bool _them;
        int _id;

        private void ucTD_Load(object sender, EventArgs e)
        {
            _them = false;
            _trinhdo = new TrinhDo();
            _showHide(true);
            loadData();
        }

        void _showHide(bool kt)
        {
            tsbLuu.Enabled = !kt;
            tsbHuy.Enabled = !kt;
            tsbThem.Enabled = kt;
            tsbSua.Enabled = kt;
            tsbXoa.Enabled = kt;
            txtTen.Enabled = !kt;
        }

        void loadData()
        {
            dgvDSTD.DataSource = _trinhdo.getList();
            // dgvDSTD.OptionsBehavior = false;// khong duong 
            // Chặn chỉnh sửa dữ liệu
            dgvDSTD.ReadOnly = true;

            // Ngăn người dùng thêm hoặc xóa dòng
            dgvDSTD.AllowUserToAddRows = false;
            dgvDSTD.AllowUserToDeleteRows = false;

            // Ngăn người dùng sắp xếp cột
            foreach (DataGridViewColumn column in dgvDSTD.Columns)
            {
                column.SortMode = DataGridViewColumnSortMode.NotSortable;
            }

            // Tắt chế độ chọn nhiều ô/cột/hàng cùng lúc
            dgvDSTD.MultiSelect = false;

            // Chặn di chuyển cột
            dgvDSTD.AllowUserToOrderColumns = false;

            // Tắt chọn cả dòng khi click vào ô
            dgvDSTD.SelectionMode = DataGridViewSelectionMode.CellSelect;
        }

        private void tsbThem_Click(object sender, EventArgs e)
        {

            _showHide(false);
            _them = true;
            txtTen.Text = string.Empty;
        }

        private void tsbSua_Click(object sender, EventArgs e)
        {
            _them = false;
            _showHide(false);
        }

        private void tsbXoa_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Ban co chac chan xoa khong?", "Thong bao", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                _trinhdo.Detele(_id);
                loadData();
            }
        }

        private void tsbLuu_Click(object sender, EventArgs e)
        {
            SaveData();
            loadData();
            _them = false;
            _showHide(true);
        }

        private void tsbHuy_Click(object sender, EventArgs e)
        {
            _them = false;
            _showHide(true);
        }

        void SaveData()
        {
            if(_them)
            {
                tb_TrinhDo td = new tb_TrinhDo();
                td.TenTD = txtTen.Text;
                _trinhdo.Add(td);
            }
            else
            {
                var td = _trinhdo.getItem(_id);
                td.TenTD = txtTen.Text;
                _trinhdo.Update(td);
            }
        }

        private void dgvDSTD_Click(object sender, EventArgs e)
        {
            _id = Convert.ToInt32(dgvDSTD.CurrentRow.Cells["IDTD"].Value);
            txtTen.Text = dgvDSTD.CurrentRow.Cells["TenTD"].Value.ToString();
        }
    }
}
