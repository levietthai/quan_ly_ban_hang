﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Windows.Forms;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using QLBH.ConnectDB;
using QLBH.DB;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace QLBH.frmQL.btnNV
{
    public partial class ucNV : UserControl
    {
        public ucNV()
        {
            InitializeComponent();
        }

        NhanVien _nhanvien;
        DanToc _dantoc;
        TonGiao _tongiao;
        ChucVu _chucvu;
        TrinhDo _trinhdo;
        bool _them;
        int _id;

        private void ucNV_Load(object sender, EventArgs e)
        {
            _them = false;
            _nhanvien = new NhanVien();
            _dantoc = new DanToc();
            _tongiao = new TonGiao();
            _chucvu = new ChucVu();
            _trinhdo = new TrinhDo();
            _showHide(true);
            loadData();
            loadCombo();
            splitContainer1.Panel1Collapsed = true;
        }

        void loadCombo()
        {
            cboTG.DataSource = _tongiao.getList();
            cboTG.DisplayMember = "TenTG";
            cboTG.ValueMember = "IDTG";

            cboTD.DataSource = _trinhdo.getList();
            cboTD.DisplayMember = "TenTD";
            cboTD.ValueMember = "IDTD";

            cboDT.DataSource = _dantoc.getList();
            cboDT.DisplayMember = "TenDT";
            cboDT.ValueMember = "IDDT";

            cboCV.DataSource = _chucvu.getList();
            cboCV.DisplayMember = "TenCV";
            cboCV.ValueMember = "IDCV";
        }
        void _showHide(bool kt)
        {
            tsbLuu.Enabled = !kt;
            tsbHuy.Enabled = !kt;
            tsbThem.Enabled = kt;
            tsbSua.Enabled = kt;
            tsbXoa.Enabled = kt;
            txtHT.Enabled = !kt;
            txtHT.Enabled = !kt;
            txtCCCD.Enabled = !kt;
            txtDT.Enabled = !kt;
            txtDC.Enabled = !kt;
            chkGioiTinh.Enabled = !kt;
            dtpNgaySinh.Enabled = !kt;
            txtTDN.Enabled = !kt;
            txtMK.Enabled = !kt;
            //pictureBox1.Enabled = !kt; 
            cboTG.Enabled = !kt;
            cboTD.Enabled = !kt;
            cboDT.Enabled = !kt;
            cboCV.Enabled = !kt;
            btnChooseImage.Enabled = !kt;
        }

        void _reset()
        {
            txtHT.Text = string.Empty;
            txtCCCD.Text = string.Empty;
            txtDT.Text = string.Empty;
            txtDC.Text = string.Empty;
            txtTDN.Text = string.Empty;
            txtMK.Text = string.Empty;
            //pictureBox1.Image = 
            chkGioiTinh.Checked = false;
        }

        void loadData()
        {
            NhanVien nv = new NhanVien();   
            dgvDSNV.DataSource = _nhanvien.getList();
            // dgvDSTD.OptionsBehavior = false;// khong duong 
            // Chặn chỉnh sửa dữ liệu
            dgvDSNV.ReadOnly = true;

            // Ngăn người dùng thêm hoặc xóa dòng
            dgvDSNV.AllowUserToAddRows = false;
            dgvDSNV.AllowUserToDeleteRows = false;

            // Ngăn người dùng sắp xếp cột
            foreach (DataGridViewColumn column in dgvDSNV.Columns)
            {
                column.SortMode = DataGridViewColumnSortMode.NotSortable;
            }

            // Tắt chế độ chọn nhiều ô/cột/hàng cùng lúc
            dgvDSNV.MultiSelect = false;

            // Chặn di chuyển cột
            dgvDSNV.AllowUserToOrderColumns = false;

            // Tắt chọn cả dòng khi click vào ô
            dgvDSNV.SelectionMode = DataGridViewSelectionMode.CellSelect;
        }

        private void tsbThem_Click(object sender, EventArgs e)
        {
            _showHide(false);
            _them = true;
            _reset();
            splitContainer1.Panel1Collapsed = false;
        }

        private void tsbSua_Click(object sender, EventArgs e)
        {
            _them = false;
            _showHide(false);
            splitContainer1.Panel1Collapsed = false;
        }

        private void tsbXoa_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Ban co chac chan xoa khong?", "Thong bao", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                _nhanvien.Detele(_id);
                loadData();
            }
        }

        private void tsbLuu_Click(object sender, EventArgs e)
        {
            SaveData();
            loadData();
            _them = false;
            _showHide(true);
            splitContainer1.Panel1Collapsed = true;
        }

        private void tsbHuy_Click(object sender, EventArgs e)
        {
            _them = false;
            _showHide(true);
            splitContainer1.Panel1Collapsed = true;
        }

        void SaveData()
        {
            if (_them)
            {
                tb_NhanVien nv = new tb_NhanVien();
                nv.HoTen = txtHT.Text;
                nv.GioiTinh = chkGioiTinh.Checked;
                nv.NgaySinh = dtpNgaySinh.Value;
                nv.DienThoai = txtDT.Text;
                nv.DiaChi = txtDC.Text;
                nv.CCCD = txtCCCD.Text;
                nv.TenDN = txtTDN.Text;
                nv.MatKhau = txtMK.Text;
                nv.HinhAnh = ImageToByteArray(pictureBox1.Image, pictureBox1.Image.RawFormat);
                nv.IDTG = int.Parse(cboTG.SelectedValue.ToString());
                nv.IDTD = int.Parse(cboTD.SelectedValue.ToString());
                nv.IDDT = int.Parse(cboDT.SelectedValue.ToString());
                nv.IDCV = int.Parse(cboCV.SelectedValue.ToString());
                _nhanvien.Add(nv);
            }
            else
            {
                var nv = _nhanvien.getItem(_id);
                nv.HoTen = txtHT.Text;
                nv.GioiTinh = chkGioiTinh.Checked;
                nv.NgaySinh = dtpNgaySinh.Value;
                nv.DienThoai = txtDT.Text;
                nv.DiaChi = txtDC.Text;
                nv.CCCD = txtCCCD.Text;
                nv.TenDN = txtTDN.Text;
                nv.MatKhau = txtMK.Text;
                nv.HinhAnh = ImageToByteArray(pictureBox1.Image, pictureBox1.Image.RawFormat);
                nv.IDTG = int.Parse(cboTG.SelectedValue.ToString());
                nv.IDTD = int.Parse(cboTD.SelectedValue.ToString());
                nv.IDDT = int.Parse(cboDT.SelectedValue.ToString());
                nv.IDCV = int.Parse(cboCV.SelectedValue.ToString());
                _nhanvien.Update(nv);
            }
        }

        private void dgvDSNV_Click(object sender, EventArgs e)
        {
            if (dgvDSNV.RowCount > 0)
            {
                _id = Convert.ToInt32(dgvDSNV.CurrentRow.Cells["MaNV"].Value);
                var nv = _nhanvien.getItem(_id);
                txtHT.Text = nv.HoTen;
                chkGioiTinh.Checked = nv.GioiTinh.Value;
                dtpNgaySinh.Value = nv.NgaySinh.Value;
                txtDT.Text = nv.DienThoai;
                txtDC.Text = nv.DiaChi;
                txtCCCD.Text = nv.CCCD;
                txtTDN.Text = nv.TenDN;
                txtMK.Text = nv.MatKhau;
                pictureBox1.Image = ByteArrayToImage(nv.HinhAnh);
                cboTG.SelectedValue = nv.IDTG;
                cboTD.SelectedValue = nv.IDTD;
                cboDT.SelectedValue = nv.IDDT;
                cboCV.SelectedValue = nv.IDCV;
            }
        }

        public byte[] ImageToByteArray(Image image, ImageFormat format)
        {
            using (MemoryStream ms = new MemoryStream())
            {
                image.Save(ms, format);
                return ms.ToArray();
            }
        }

        public Image ByteArrayToImage(byte[] imageBytes)
        {
            using (MemoryStream ms = new MemoryStream(imageBytes))
            {
                return Image.FromStream(ms);
            }
        }

        private void btnChooseImage_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Picter Files (.png, .jpg)|*.png; *.jpg";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.Image = Image.FromFile(openFileDialog.FileName);
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            }
        }
    }
}
