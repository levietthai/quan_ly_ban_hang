﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using QLBH.ConnectDB;
using QLBH.DB;

namespace QLBH.frmQL.btnNV
{
    public partial class ucTG : UserControl
    {
        public ucTG()
        {
            InitializeComponent();
        }

        TonGiao _tongiao;
        bool _them;
        int _id;

        private void ucTG_Load(object sender, EventArgs e)
        {
            _them = false;
            _tongiao = new TonGiao();
            _showHide(true);
            loadData();
        }

        void _showHide(bool kt)
        {
            tsbLuu.Enabled = !kt;
            tsbHuy.Enabled = !kt;
            tsbThem.Enabled = kt;
            tsbSua.Enabled = kt;
            tsbXoa.Enabled = kt;
            txtTen.Enabled = !kt;
        }

        void loadData()
        {
            dgvDSTG.DataSource = _tongiao.getList();
            // dgvDSTD.OptionsBehavior = false;// khong duong 
            // Chặn chỉnh sửa dữ liệu
            dgvDSTG.ReadOnly = true;

            // Ngăn người dùng thêm hoặc xóa dòng
            dgvDSTG.AllowUserToAddRows = false;
            dgvDSTG.AllowUserToDeleteRows = false;

            // Ngăn người dùng sắp xếp cột
            foreach (DataGridViewColumn column in dgvDSTG.Columns)
            {
                column.SortMode = DataGridViewColumnSortMode.NotSortable;
            }

            // Tắt chế độ chọn nhiều ô/cột/hàng cùng lúc
            dgvDSTG.MultiSelect = false;

            // Chặn di chuyển cột
            dgvDSTG.AllowUserToOrderColumns = false;

            // Tắt chọn cả dòng khi click vào ô
            dgvDSTG.SelectionMode = DataGridViewSelectionMode.CellSelect;
        }

        private void tsbThem_Click(object sender, EventArgs e)
        {
            _showHide(false);
            _them = true;
            txtTen.Text = string.Empty;
        }

        private void tsbSua_Click(object sender, EventArgs e)
        {
            _them = false;
            _showHide(false);
        }

        private void tsbXoa_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Ban co chac chan xoa khong?", "Thong bao", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                _tongiao.Detele(_id);
                loadData();
            }
        }

        private void tsbLuu_Click(object sender, EventArgs e)
        {
            SaveData();
            loadData();
            _them = false;
            _showHide(true);
        }

        private void tsbHuy_Click(object sender, EventArgs e)
        {
            _them = false;
            _showHide(true);
        }

        void SaveData()
        {
            if (_them)
            {
                tb_TonGiao tg = new tb_TonGiao();
                tg.TenTG = txtTen.Text;
                _tongiao.Add(tg);
            }
            else
            {
                var tg = _tongiao.getItem(_id);
                tg.TenTG = txtTen.Text;
                _tongiao.Update(tg);
            }
        }

        private void dgvDSTG_Click(object sender, EventArgs e)
        {
            _id = Convert.ToInt32(dgvDSTG.CurrentRow.Cells["IDTG"].Value);
            txtTen.Text = dgvDSTG.CurrentRow.Cells["TenTG"].Value.ToString();
        }
    }
}
