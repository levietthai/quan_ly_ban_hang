﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLBH.frmQL
{
    public partial class ucCatelogyMana : UserControl
    {
        private ucDM dm;
        private ucSP sp;
        public ucCatelogyMana()
        {
            dm = new ucDM();
            sp = new ucSP();
            InitializeComponent();
        }

        private void btnDM_Click(object sender, EventArgs e)
        {
            flpDM.Controls.Clear();
            flpDM.Controls.Add(dm);
        }

        private void btnSP_Click(object sender, EventArgs e)
        {
            flpDM.Controls.Clear();
            flpDM.Controls.Add(sp);
        }
    }
}

