﻿namespace QLBH.frmQL
{
    partial class ucCatelogyMana
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucCatelogyMana));
            this.flpDM = new System.Windows.Forms.FlowLayoutPanel();
            this.panalDM = new System.Windows.Forms.Panel();
            this.btnSP = new System.Windows.Forms.Button();
            this.btnDM = new System.Windows.Forms.Button();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.panalDM.SuspendLayout();
            this.SuspendLayout();
            // 
            // flpDM
            // 
            this.flpDM.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.flpDM.AutoScroll = true;
            this.flpDM.Location = new System.Drawing.Point(268, 2);
            this.flpDM.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.flpDM.Name = "flpDM";
            this.flpDM.Size = new System.Drawing.Size(1412, 726);
            this.flpDM.TabIndex = 4;
            // 
            // panalDM
            // 
            this.panalDM.BackColor = System.Drawing.Color.Lavender;
            this.panalDM.Controls.Add(this.btnSP);
            this.panalDM.Controls.Add(this.btnDM);
            this.panalDM.Cursor = System.Windows.Forms.Cursors.Default;
            this.panalDM.Dock = System.Windows.Forms.DockStyle.Left;
            this.panalDM.Location = new System.Drawing.Point(0, 0);
            this.panalDM.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panalDM.Name = "panalDM";
            this.panalDM.Size = new System.Drawing.Size(260, 730);
            this.panalDM.TabIndex = 3;
            // 
            // btnSP
            // 
            this.btnSP.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSP.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSP.ImageIndex = 0;
            this.btnSP.ImageList = this.imageList1;
            this.btnSP.Location = new System.Drawing.Point(51, 319);
            this.btnSP.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnSP.Name = "btnSP";
            this.btnSP.Size = new System.Drawing.Size(144, 43);
            this.btnSP.TabIndex = 1;
            this.btnSP.Text = "Sản phẩm";
            this.btnSP.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSP.UseVisualStyleBackColor = true;
            this.btnSP.Click += new System.EventHandler(this.btnSP_Click);
            // 
            // btnDM
            // 
            this.btnDM.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDM.ImageIndex = 1;
            this.btnDM.ImageList = this.imageList1;
            this.btnDM.Location = new System.Drawing.Point(51, 220);
            this.btnDM.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnDM.Name = "btnDM";
            this.btnDM.Size = new System.Drawing.Size(144, 42);
            this.btnDM.TabIndex = 0;
            this.btnDM.Text = "Danh mục";
            this.btnDM.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDM.UseVisualStyleBackColor = true;
            this.btnDM.Click += new System.EventHandler(this.btnDM_Click);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "boxes.png");
            this.imageList1.Images.SetKeyName(1, "menu.png");
            // 
            // ucCatelogyMana
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.flpDM);
            this.Controls.Add(this.panalDM);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "ucCatelogyMana";
            this.Size = new System.Drawing.Size(1699, 730);
            this.panalDM.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel flpDM;
        private System.Windows.Forms.Panel panalDM;
        private System.Windows.Forms.Button btnSP;
        private System.Windows.Forms.Button btnDM;
        private System.Windows.Forms.ImageList imageList1;
    }
}
