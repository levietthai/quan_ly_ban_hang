﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using QLBH.frmQL.btnNV;

namespace QLBH.frmQL
{
    public partial class ucStaffMana : UserControl
    {
        private ucNV nv;
        private ucCV cv;
        private ucTD td;
        private ucTG tg;
        private ucDT dt;
        public ucStaffMana()
        {
            nv = new ucNV();
            cv = new ucCV();
            td = new ucTD();
            dt = new ucDT();
            tg = new ucTG();
            InitializeComponent();
        }

        private void btnNV_Click(object sender, EventArgs e)
        {
            flpNV.Controls.Clear();
            //staff.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top | AnchorStyles.Bottom;
            //staff.Dock = DockStyle.Fill;
            flpNV.Controls.Add(nv);
        }

        private void btnCV_Click(object sender, EventArgs e)
        {
            flpNV.Controls.Clear();
            flpNV.Controls.Add(cv);
        }

        private void btnTD_Click(object sender, EventArgs e)
        {
            flpNV.Controls.Clear();
            flpNV.Controls.Add(td);
        }

        private void btnTG_Click(object sender, EventArgs e)
        {
            flpNV.Controls.Clear();
            flpNV.Controls.Add(tg);
        }

        private void btnDT_Click(object sender, EventArgs e)
        {
            flpNV.Controls.Clear();
            flpNV.Controls.Add(dt);
        }
    }
}
