﻿namespace QLBH.frmQL
{
    partial class ucStaffMana
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucStaffMana));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnDT = new System.Windows.Forms.Button();
            this.btnTG = new System.Windows.Forms.Button();
            this.btnTD = new System.Windows.Forms.Button();
            this.btnCV = new System.Windows.Forms.Button();
            this.btnNV = new System.Windows.Forms.Button();
            this.flpNV = new System.Windows.Forms.FlowLayoutPanel();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Lavender;
            this.panel1.Controls.Add(this.btnDT);
            this.panel1.Controls.Add(this.btnTG);
            this.panel1.Controls.Add(this.btnTD);
            this.panel1.Controls.Add(this.btnCV);
            this.panel1.Controls.Add(this.btnNV);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(181, 590);
            this.panel1.TabIndex = 0;
            // 
            // btnDT
            // 
            this.btnDT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDT.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDT.ImageIndex = 3;
            this.btnDT.ImageList = this.imageList1;
            this.btnDT.Location = new System.Drawing.Point(28, 309);
            this.btnDT.Name = "btnDT";
            this.btnDT.Size = new System.Drawing.Size(130, 32);
            this.btnDT.TabIndex = 4;
            this.btnDT.Text = "Dân tộc";
            this.btnDT.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDT.UseVisualStyleBackColor = true;
            this.btnDT.Click += new System.EventHandler(this.btnDT_Click);
            // 
            // btnTG
            // 
            this.btnTG.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTG.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTG.ImageIndex = 1;
            this.btnTG.ImageList = this.imageList1;
            this.btnTG.Location = new System.Drawing.Point(28, 262);
            this.btnTG.Name = "btnTG";
            this.btnTG.Size = new System.Drawing.Size(130, 32);
            this.btnTG.TabIndex = 3;
            this.btnTG.Text = "Tôn giáo";
            this.btnTG.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnTG.UseVisualStyleBackColor = true;
            this.btnTG.Click += new System.EventHandler(this.btnTG_Click);
            // 
            // btnTD
            // 
            this.btnTD.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTD.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTD.ImageIndex = 2;
            this.btnTD.ImageList = this.imageList1;
            this.btnTD.Location = new System.Drawing.Point(28, 213);
            this.btnTD.Name = "btnTD";
            this.btnTD.Size = new System.Drawing.Size(130, 32);
            this.btnTD.TabIndex = 2;
            this.btnTD.Text = "Trình độ";
            this.btnTD.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnTD.UseVisualStyleBackColor = true;
            this.btnTD.Click += new System.EventHandler(this.btnTD_Click);
            // 
            // btnCV
            // 
            this.btnCV.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCV.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCV.ImageIndex = 4;
            this.btnCV.ImageList = this.imageList1;
            this.btnCV.Location = new System.Drawing.Point(28, 160);
            this.btnCV.Name = "btnCV";
            this.btnCV.Size = new System.Drawing.Size(130, 32);
            this.btnCV.TabIndex = 1;
            this.btnCV.Text = "Chức vụ";
            this.btnCV.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCV.UseVisualStyleBackColor = true;
            this.btnCV.Click += new System.EventHandler(this.btnCV_Click);
            // 
            // btnNV
            // 
            this.btnNV.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNV.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNV.ImageIndex = 0;
            this.btnNV.ImageList = this.imageList1;
            this.btnNV.Location = new System.Drawing.Point(28, 112);
            this.btnNV.Name = "btnNV";
            this.btnNV.Size = new System.Drawing.Size(130, 32);
            this.btnNV.TabIndex = 0;
            this.btnNV.Text = "Nhân Viên";
            this.btnNV.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNV.UseVisualStyleBackColor = true;
            this.btnNV.Click += new System.EventHandler(this.btnNV_Click);
            // 
            // flpNV
            // 
            this.flpNV.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.flpNV.AutoScroll = true;
            this.flpNV.Location = new System.Drawing.Point(192, 0);
            this.flpNV.Name = "flpNV";
            this.flpNV.Size = new System.Drawing.Size(1071, 590);
            this.flpNV.TabIndex = 1;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "Nhan vien.png");
            this.imageList1.Images.SetKeyName(1, "ton giao.png");
            this.imageList1.Images.SetKeyName(2, "trinh do.png");
            this.imageList1.Images.SetKeyName(3, "dan toc.png");
            this.imageList1.Images.SetKeyName(4, "location.png");
            // 
            // ucStaffMana
            // 
            this.AllowDrop = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.Controls.Add(this.flpNV);
            this.Controls.Add(this.panel1);
            this.Name = "ucStaffMana";
            this.Size = new System.Drawing.Size(1274, 593);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.FlowLayoutPanel flpNV;
        private System.Windows.Forms.Button btnNV;
        private System.Windows.Forms.Button btnTD;
        private System.Windows.Forms.Button btnCV;
        private System.Windows.Forms.Button btnDT;
        private System.Windows.Forms.Button btnTG;
        private System.Windows.Forms.ImageList imageList1;
    }
}
