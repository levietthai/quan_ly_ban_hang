﻿namespace QLBH.Properties
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
            this.btn_Back = new System.Windows.Forms.Button();
            this.btn_Login = new System.Windows.Forms.Button();
            this.txt_Password = new System.Windows.Forms.TextBox();
            this.txt_User = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.lbl_User = new System.Windows.Forms.Label();
            this.btn_Dow = new System.Windows.Forms.Button();
            this.btn_EyeUp = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_Back
            // 
            this.btn_Back.Location = new System.Drawing.Point(415, 614);
            this.btn_Back.Name = "btn_Back";
            this.btn_Back.Size = new System.Drawing.Size(152, 41);
            this.btn_Back.TabIndex = 25;
            this.btn_Back.Text = "Trở lại";
            this.btn_Back.UseVisualStyleBackColor = true;
            this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
            // 
            // btn_Login
            // 
            this.btn_Login.Location = new System.Drawing.Point(648, 614);
            this.btn_Login.Name = "btn_Login";
            this.btn_Login.Size = new System.Drawing.Size(152, 41);
            this.btn_Login.TabIndex = 24;
            this.btn_Login.Text = "Đăng nhập";
            this.btn_Login.UseVisualStyleBackColor = true;
            this.btn_Login.Click += new System.EventHandler(this.btn_Login_Click);
            // 
            // txt_Password
            // 
            this.txt_Password.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_Password.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Password.Location = new System.Drawing.Point(415, 417);
            this.txt_Password.Name = "txt_Password";
            this.txt_Password.PasswordChar = '*';
            this.txt_Password.Size = new System.Drawing.Size(385, 30);
            this.txt_Password.TabIndex = 21;
            // 
            // txt_User
            // 
            this.txt_User.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_User.Location = new System.Drawing.Point(415, 262);
            this.txt_User.Name = "txt_User";
            this.txt_User.Size = new System.Drawing.Size(385, 30);
            this.txt_User.TabIndex = 20;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(410, 374);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(67, 16);
            this.label4.TabIndex = 19;
            this.label4.Text = "Mật khẩu :";
            // 
            // lbl_User
            // 
            this.lbl_User.AutoSize = true;
            this.lbl_User.Location = new System.Drawing.Point(410, 221);
            this.lbl_User.Name = "lbl_User";
            this.lbl_User.Size = new System.Drawing.Size(104, 16);
            this.lbl_User.TabIndex = 18;
            this.lbl_User.Text = "Tên đăng nhập :";
            // 
            // btn_Dow
            // 
            this.btn_Dow.BackColor = System.Drawing.Color.White;
            this.btn_Dow.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Dow.ForeColor = System.Drawing.Color.Black;
            this.btn_Dow.Image = ((System.Drawing.Image)(resources.GetObject("btn_Dow.Image")));
            this.btn_Dow.Location = new System.Drawing.Point(766, 417);
            this.btn_Dow.Name = "btn_Dow";
            this.btn_Dow.Size = new System.Drawing.Size(34, 29);
            this.btn_Dow.TabIndex = 29;
            this.btn_Dow.UseVisualStyleBackColor = false;
            this.btn_Dow.Click += new System.EventHandler(this.btn_Dow_Click);
            // 
            // btn_EyeUp
            // 
            this.btn_EyeUp.BackColor = System.Drawing.Color.White;
            this.btn_EyeUp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_EyeUp.ForeColor = System.Drawing.Color.Black;
            this.btn_EyeUp.Image = ((System.Drawing.Image)(resources.GetObject("btn_EyeUp.Image")));
            this.btn_EyeUp.Location = new System.Drawing.Point(766, 417);
            this.btn_EyeUp.Name = "btn_EyeUp";
            this.btn_EyeUp.Size = new System.Drawing.Size(34, 29);
            this.btn_EyeUp.TabIndex = 28;
            this.btn_EyeUp.UseVisualStyleBackColor = false;
            this.btn_EyeUp.Click += new System.EventHandler(this.btn_EyeUp_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(430, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(330, 69);
            this.label1.TabIndex = 30;
            this.label1.Text = "Đăng Nhập";
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1312, 753);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_Dow);
            this.Controls.Add(this.btn_EyeUp);
            this.Controls.Add(this.btn_Back);
            this.Controls.Add(this.btn_Login);
            this.Controls.Add(this.txt_Password);
            this.Controls.Add(this.txt_User);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lbl_User);
            this.Name = "Login";
            this.Text = "Login";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Dow;
        private System.Windows.Forms.Button btn_EyeUp;
        private System.Windows.Forms.Button btn_Back;
        private System.Windows.Forms.Button btn_Login;
        private System.Windows.Forms.TextBox txt_Password;
        private System.Windows.Forms.TextBox txt_User;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lbl_User;
        private System.Windows.Forms.Label label1;
    }
}