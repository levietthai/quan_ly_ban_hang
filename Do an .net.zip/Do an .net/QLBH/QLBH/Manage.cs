﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using QLBH.frmQL;

namespace QLBH
{
    public partial class Manage : Form
    {
        private ucCatelogyMana catelogy;
        private ucStaffMana staff;
        private ucCustomersMana customer;
        private ucRevenueMana revenue;
        private ucBillMana bill;
        private List<Button> buttons;

        public Manage()
        {
            staff = new ucStaffMana();
            customer = new ucCustomersMana();
            revenue = new ucRevenueMana();
            catelogy = new ucCatelogyMana();
            bill = new ucBillMana();
            InitializeComponent();
        }

        private void btnNV_Click(object sender, EventArgs e)
        {
            flpQL.Controls.Clear();
            //staff.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top | AnchorStyles.Bottom;
            //staff.Dock = DockStyle.Fill;
            flpQL.Controls.Add(staff);
        }

        private void btnKH_Click(object sender, EventArgs e)
        {
            flpQL.Controls.Clear();
            flpQL.Controls.Add(catelogy);
        }

        private void btnHD_Click(object sender, EventArgs e)
        {
            flpQL.Controls.Clear();
            flpQL.Controls.Add(bill);
        }

        private void btnDT_Click(object sender, EventArgs e)
        {
            flpQL.Controls.Clear();
            flpQL.Controls.Add(revenue);
        }

        private void Manage_Load(object sender, EventArgs e)
        {
            buttons = new List<Button> { btnNV, btnKH, btnHD, btnKH };

            foreach (var button in buttons)
            {
                button.Click += Button_Click;
            }
        }
        private void Button_Click(object sender, EventArgs e)
        {
            // Xác định Button được nhấn
            Button clickedButton = sender as Button;

            // Đổi màu tất cả các Button về màu mặc định
            foreach (var button in buttons)
            {
                button.BackColor = Color.CornflowerBlue; // Màu mặc định
            }

            // Đổi màu Button được chọn
            clickedButton.BackColor = Color.LightBlue; // Màu khi được chọn
        }

        private void btnDK_Click(object sender, EventArgs e)
        {
            DangKy dk = new DangKy();
            dk.Show();
        }
    }
}
