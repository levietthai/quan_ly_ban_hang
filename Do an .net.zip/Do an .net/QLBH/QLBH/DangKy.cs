﻿using QLBH.ConnectDB;
using QLBH.DB;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLBH
{
    public partial class DangKy : Form
    {
        public DangKy()
        {
            InitializeComponent();
            _dangky = new DangKyclass();
        }
        DangKyclass _dangky;
        bool _them;
        int _id;

        private void DangKy_Load(object sender, EventArgs e)
        {
            _them = false;
        }

        void SaveData()
        {
            try
            {
                tb_Users us = new tb_Users();
                us.UserName = txtTDN.Text;
                us.Password = txtMK.Text;
                _dangky.Add(us);
                MessageBox.Show("Đăng ký thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi thêm dữ liệu: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void tbnThem_Click(object sender, EventArgs e)
        {
            SaveData();
            _them = true;
        }
    }
}

