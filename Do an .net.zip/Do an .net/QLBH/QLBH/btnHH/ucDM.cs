﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using QLBH.ConnectDB;
using QLBH.DB;

namespace QLBH
{
    public partial class ucDM : UserControl
    {
        public ucDM()
        {
            InitializeComponent();
        }
        DM _danhmuc;
        bool _them;
        int _id;

        private void ucDM_Load(object sender, EventArgs e)
        {
            _them = false;
            _danhmuc = new DM();
            _showHide(true);
            loadData();
        }

        void _showHide(bool kt)
        {
            tsbLuu.Enabled = !kt;
            tsbHuy.Enabled = !kt;
            tsbThem.Enabled = kt;
            tsbSua.Enabled = kt;
            tsbXoa.Enabled = kt;
            txtTDM.Enabled = !kt;
        }

        void loadData()
        {
            dgvDSDM.DataSource = _danhmuc.getList();
            // dgvDSTD.OptionsBehavior = false;// khong duong 
            // Chặn chỉnh sửa dữ liệu
            dgvDSDM.ReadOnly = true;

            // Ngăn người dùng thêm hoặc xóa dòng
            dgvDSDM.AllowUserToAddRows = false;
            dgvDSDM.AllowUserToDeleteRows = false;

            // Ngăn người dùng sắp xếp cột
            foreach (DataGridViewColumn column in dgvDSDM.Columns)
            {
                column.SortMode = DataGridViewColumnSortMode.NotSortable;
            }

            // Tắt chế độ chọn nhiều ô/cột/hàng cùng lúc
            dgvDSDM.MultiSelect = false;

            // Chặn di chuyển cột
            dgvDSDM.AllowUserToOrderColumns = false;

            // Tắt chọn cả dòng khi click vào ô
            dgvDSDM.SelectionMode = DataGridViewSelectionMode.CellSelect;
        }
        private void tsbThem_Click(object sender, EventArgs e)
        {
            _showHide(false);
            _them = true;
            txtTDM.Text = string.Empty;
        }

        private void tsbSua_Click(object sender, EventArgs e)
        {
            _them = false;
            _showHide(false);
        }

        private void tsbXoa_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Ban co chac chan xoa khong?", "Thong bao", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                _danhmuc.Detele(_id);
                loadData();
            }
        }

        private void tsbLuu_Click(object sender, EventArgs e)
        {
            SaveData();
            loadData();
            _them = false;
            _showHide(true);
        }

        private void tsbHuy_Click(object sender, EventArgs e)
        {
            _them = false;
            _showHide(true);
        }

        void SaveData()
        {
            if (_them)
            {
                tb_DanhMucSP dm = new tb_DanhMucSP();
                dm.TenDM = txtTDM.Text;
                _danhmuc.Add(dm);
            }
            else
            {
                var dt = _danhmuc.getItem(_id);
                dt.TenDM = txtTDM.Text;
                _danhmuc.Update(dt);
            }
        }

        private void dvgDSDM_Click(object sender, EventArgs e)
        {
            _id = Convert.ToInt32(dgvDSDM.CurrentRow.Cells["MaDM"].Value);
            txtTDM.Text = dgvDSDM.CurrentRow.Cells["TenDM"].Value.ToString();
        }
    }
}
