﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using QLBH.ConnectDB;
using QLBH.DB;

namespace QLBH
{
    public partial class ucSP : UserControl
    {
        public ucSP()
        {
            InitializeComponent();
        }
        DM _danhmuc;
        SP _sanpham;
        bool _them;
        int _id;


        private void ucSP_Load(object sender, EventArgs e)
        {
            _them = false;
            _sanpham = new SP();
            _danhmuc = new DM();
            _showHide(true);
            loadData();
            loadCombo();
            splitContainer1.Panel1Collapsed = true;
        }


        void loadCombo()
        {
            cboTDM.DataSource = _danhmuc.getList();
            cboTDM.DisplayMember = "TenDM";
            cboTDM.ValueMember = "MaDM";
        }
        void _showHide(bool kt)
        {
            tsbLuu.Enabled = !kt;
            tsbHuy.Enabled = !kt;
            tsbThem.Enabled = kt;
            tsbSua.Enabled = kt;
            tsbXoa.Enabled = kt;
            txtTSP.Enabled = !kt;
            txtSL.Enabled = !kt;
            txtHSD.Enabled = !kt;
            txtGN.Enabled = !kt;
            txtGB.Enabled = !kt;
            //pictureBox1.Enabled = !kt; 
            cboTDM.Enabled = !kt;
            btnChooseImage.Enabled = !kt;
        }

        void _reset()
        {
            txtGB.Text = string.Empty;
            txtGN.Text = string.Empty;
            txtHSD.Text = string.Empty;
            txtSL.Text = string.Empty;
            txtTSP.Text = string.Empty;
            //pictureBox1.Image = 
            cboTDM.Text = string.Empty;
        }

        void loadData()
        {
            SP nv = new SP();
            dgvDSSP.DataSource = _sanpham.getList();
            // dgvDSTD.OptionsBehavior = false;// khong duong 
            // Chặn chỉnh sửa dữ liệu
            dgvDSSP.ReadOnly = true;

            // Ngăn người dùng thêm hoặc xóa dòng
            dgvDSSP.AllowUserToAddRows = false;
            dgvDSSP.AllowUserToDeleteRows = false;

            // Ngăn người dùng sắp xếp cột
            foreach (DataGridViewColumn column in dgvDSSP.Columns)
            {
                column.SortMode = DataGridViewColumnSortMode.NotSortable;
            }

            // Tắt chế độ chọn nhiều ô/cột/hàng cùng lúc
            dgvDSSP.MultiSelect = false;

            // Chặn di chuyển cột
            dgvDSSP.AllowUserToOrderColumns = false;

            // Tắt chọn cả dòng khi click vào ô
            dgvDSSP.SelectionMode = DataGridViewSelectionMode.CellSelect;
        }

        private void tsbThem_Click(object sender, EventArgs e)
        {
            _showHide(false);
            _them = true;
            _reset();
            splitContainer1.Panel1Collapsed = false;
        }

        private void tsbSua_Click(object sender, EventArgs e)
        {
            _them = false;
            _showHide(false);
            splitContainer1.Panel1Collapsed = false;
        }

        private void tsbXoa_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Ban co chac chan xoa khong?", "Thong bao", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                _sanpham.Detele(_id);
                loadData();
            }
        }

        private void tsbLuu_Click(object sender, EventArgs e)
        {
            SaveData();
            loadData();
            _them = false;
            _showHide(true);
            splitContainer1.Panel1Collapsed = true;
        }

        private void tsbHuy_Click(object sender, EventArgs e)
        {
            _them = false;
            _showHide(true);
            splitContainer1.Panel1Collapsed = true;
        }
        void SaveData()
        {
            if (_them)
            {
                tb_SanPham sp = new tb_SanPham();
                sp.TenSP = txtTSP.Text;
                sp.GiaBan = txtGB.Text;
                sp.GiaNhap = txtGN.Text;
                sp.SoLuongTonKho = txtSL.Text;
                sp.HSD = txtHSD.Text;
                sp.Hinhanh = ImageToByteArray(pictureBox1.Image, pictureBox1.Image.RawFormat);
                sp.MaDM = int.Parse(cboTDM.SelectedValue.ToString());
                _sanpham.Add(sp);
            }
            else
            {
                var sp = _sanpham.getItem(_id);
                sp.TenSP = txtTSP.Text;
                sp.GiaBan = txtGB.Text;
                sp.GiaNhap = txtGN.Text;
                sp.SoLuongTonKho = txtSL.Text;
                sp.HSD = txtHSD.Text;
                sp.Hinhanh = ImageToByteArray(pictureBox1.Image, pictureBox1.Image.RawFormat);
                sp.MaDM = int.Parse(cboTDM.SelectedValue.ToString());
                _sanpham.Update(sp);
            }
        }

        private void dgvDSSP_Click(object sender, EventArgs e)
        {
            if (dgvDSSP.RowCount > 0)
            {
                _id = Convert.ToInt32(dgvDSSP.CurrentRow.Cells["MaSP"].Value);
                var sp = _sanpham.getItem(_id);
                txtTSP.Text = sp.TenSP;
                txtGB.Text = sp.GiaBan.ToString();
                txtGN.Text = sp.GiaNhap.ToString();
                txtSL.Text = sp.SoLuongTonKho.ToString();
                txtHSD.Text = sp.HSD;
                pictureBox1.Image = ByteArrayToImage(sp.Hinhanh);
                cboTDM.SelectedValue = sp.MaDM;
            }
        }
        public byte[] ImageToByteArray(Image image, ImageFormat format)
        {
            using (MemoryStream ms = new MemoryStream())
            {
                image.Save(ms, format);
                return ms.ToArray();
            }
        }

        public Image ByteArrayToImage(byte[] imageBytes)
        {
            using (MemoryStream ms = new MemoryStream(imageBytes))
            {
                return Image.FromStream(ms);
            }
        }

        private void btnChooseImage_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Picter Files (.png, .jpg)|*.png; *.jpg";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.Image = Image.FromFile(openFileDialog.FileName);
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            }
        }
    }
}
