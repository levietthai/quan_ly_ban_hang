﻿using QLBH.DB;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLBH.Properties
{
    public partial class Login : Form
    {
        QUANLYBANHANGEntities db = new QUANLYBANHANGEntities();
        
        public Login()
        {
            InitializeComponent();
        }

        private void btn_Login_Click(object sender, EventArgs e)
        {
            string userName = txt_User.Text;
            string passWord = txt_Password.Text;

            try
            {
                // Kiểm tra tài khoản trong CSDL bằng Entity Framework
                var user = db.tb_Users.FirstOrDefault(u => u.UserName == userName && u.Password == passWord);

                if (user != null) // Nếu tìm thấy tài khoản
                {
                    Manage qlkhForm = new Manage();
                    qlkhForm.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Tên đăng nhập hoặc mật khẩu không đúng!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_EyeUp_Click(object sender, EventArgs e)
        {
            if (txt_Password.PasswordChar == '\0')
            {
                btn_Dow.BringToFront();
                txt_Password.PasswordChar = '*';
            }
        }
        private void btn_Dow_Click(object sender, EventArgs e)
        {
            if (txt_Password.PasswordChar == '*')
            {
                btn_EyeUp.BringToFront();
                txt_Password.PasswordChar = '\0';
            }
        }

        private void btn_Back_Click(object sender, EventArgs e)
        {
            Dispose(); // back
        }
    }
}
