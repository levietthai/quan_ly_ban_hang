﻿namespace QLBH
{
    partial class Manage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Manage));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnKH = new System.Windows.Forms.Button();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.btnHD = new System.Windows.Forms.Button();
            this.btnNV = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblTQL = new System.Windows.Forms.Label();
            this.flpQL = new System.Windows.Forms.FlowLayoutPanel();
            this.btnDK = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel1.Controls.Add(this.btnDK);
            this.panel1.Controls.Add(this.btnKH);
            this.panel1.Controls.Add(this.btnHD);
            this.panel1.Controls.Add(this.btnNV);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.lblTQL);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1456, 128);
            this.panel1.TabIndex = 7;
            // 
            // btnKH
            // 
            this.btnKH.FlatAppearance.BorderColor = System.Drawing.Color.CornflowerBlue;
            this.btnKH.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnKH.ForeColor = System.Drawing.Color.White;
            this.btnKH.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnKH.ImageIndex = 7;
            this.btnKH.ImageList = this.imageList1;
            this.btnKH.Location = new System.Drawing.Point(432, 32);
            this.btnKH.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnKH.Name = "btnKH";
            this.btnKH.Size = new System.Drawing.Size(196, 47);
            this.btnKH.TabIndex = 23;
            this.btnKH.Text = "Kho hàng";
            this.btnKH.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnKH.UseVisualStyleBackColor = true;
            this.btnKH.Click += new System.EventHandler(this.btnKH_Click);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "bill.png");
            this.imageList1.Images.SetKeyName(1, "Khach hang.png");
            this.imageList1.Images.SetKeyName(2, "logout.png");
            this.imageList1.Images.SetKeyName(3, "Nhan vien.png");
            this.imageList1.Images.SetKeyName(4, "nhanvien.png");
            this.imageList1.Images.SetKeyName(5, "supply.png");
            this.imageList1.Images.SetKeyName(6, "public-relation.png");
            this.imageList1.Images.SetKeyName(7, "boxes.png");
            this.imageList1.Images.SetKeyName(8, "goods.png");
            this.imageList1.Images.SetKeyName(9, "increase.png");
            this.imageList1.Images.SetKeyName(10, "user.png");
            // 
            // btnHD
            // 
            this.btnHD.FlatAppearance.BorderColor = System.Drawing.Color.CornflowerBlue;
            this.btnHD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHD.ForeColor = System.Drawing.Color.White;
            this.btnHD.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHD.ImageIndex = 0;
            this.btnHD.ImageList = this.imageList1;
            this.btnHD.Location = new System.Drawing.Point(697, 32);
            this.btnHD.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnHD.Name = "btnHD";
            this.btnHD.Size = new System.Drawing.Size(196, 47);
            this.btnHD.TabIndex = 19;
            this.btnHD.Text = "Hóa đơn";
            this.btnHD.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnHD.UseVisualStyleBackColor = true;
            this.btnHD.Click += new System.EventHandler(this.btnHD_Click);
            // 
            // btnNV
            // 
            this.btnNV.BackColor = System.Drawing.Color.CornflowerBlue;
            this.btnNV.CausesValidation = false;
            this.btnNV.FlatAppearance.BorderColor = System.Drawing.Color.CornflowerBlue;
            this.btnNV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNV.ForeColor = System.Drawing.Color.White;
            this.btnNV.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNV.ImageIndex = 3;
            this.btnNV.ImageList = this.imageList1;
            this.btnNV.Location = new System.Drawing.Point(185, 32);
            this.btnNV.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnNV.Name = "btnNV";
            this.btnNV.Size = new System.Drawing.Size(196, 47);
            this.btnNV.TabIndex = 10;
            this.btnNV.Text = "Nhân viên";
            this.btnNV.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNV.UseVisualStyleBackColor = false;
            this.btnNV.Click += new System.EventHandler(this.btnNV_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::QLBH.Properties.Resources.user;
            this.pictureBox1.Location = new System.Drawing.Point(16, 15);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(113, 74);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            // 
            // lblTQL
            // 
            this.lblTQL.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblTQL.AutoSize = true;
            this.lblTQL.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTQL.Location = new System.Drawing.Point(32, 92);
            this.lblTQL.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTQL.Name = "lblTQL";
            this.lblTQL.Size = new System.Drawing.Size(75, 22);
            this.lblTQL.TabIndex = 9;
            this.lblTQL.Text = "Quan Ly";
            // 
            // flpQL
            // 
            this.flpQL.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.flpQL.Location = new System.Drawing.Point(0, 135);
            this.flpQL.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.flpQL.Name = "flpQL";
            this.flpQL.Size = new System.Drawing.Size(1456, 418);
            this.flpQL.TabIndex = 8;
            // 
            // btnDK
            // 
            this.btnDK.Location = new System.Drawing.Point(1305, 41);
            this.btnDK.Margin = new System.Windows.Forms.Padding(4);
            this.btnDK.Name = "btnDK";
            this.btnDK.Size = new System.Drawing.Size(100, 28);
            this.btnDK.TabIndex = 25;
            this.btnDK.Text = "Đăng Ký";
            this.btnDK.UseVisualStyleBackColor = true;
            this.btnDK.Click += new System.EventHandler(this.btnDK_Click);
            // 
            // Manage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1456, 554);
            this.Controls.Add(this.flpQL);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Manage";
            this.Text = "Manage";
            this.Load += new System.EventHandler(this.Manage_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnKH;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Button btnHD;
        private System.Windows.Forms.Button btnNV;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblTQL;
        private System.Windows.Forms.FlowLayoutPanel flpQL;
        private System.Windows.Forms.Button btnDK;
    }
}